"use client"

import Link from "next/link"
import { useSession, signOut } from "next-auth/react"
import Image from "next/image"

export default function Navbar() {
  const { data: session } = useSession()

  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="text-xl font-bold text-zinc-800">
              Şükür Günlüğü
            </Link>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <Link
                  href="/anasayfa"
                  className="text-zinc-600 hover:bg-zinc-100 px-3 py-2 rounded-md text-sm font-medium"
                >
                  Anasayfa
                </Link>
                <Link
                  href="/gecmis"
                  className="text-zinc-600 hover:bg-zinc-100 px-3 py-2 rounded-md text-sm font-medium"
                >
                  Geçmiş
                </Link>
                <Link
                  href="/profil"
                  className="text-zinc-600 hover:bg-zinc-100 px-3 py-2 rounded-md text-sm font-medium"
                >
                  Profil
                </Link>
              </div>
            </div>
          </div>
          <div className="hidden md:block">
            {session?.user && (
              <div className="ml-4 flex items-center md:ml-6">
                {session.user.image && (
                  <Image
                    src={session.user.image}
                    alt={session.user.name || "User"}
                    width={32}
                    height={32}
                    className="rounded-full"
                  />
                )}
                <button
                  onClick={() => signOut()}
                  className="ml-4 px-3 py-2 font-medium text-sm text-white bg-red-500 rounded-md hover:bg-red-600 transition-colors"
                >
                  Çıkış Yap
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  )
}
