"use client"

import { useSession, signOut } from "next-auth/react"
import Image from "next/image"
import { useRouter } from "next/navigation"

export default function Profil() {
  const { data: session, status } = useSession()
  const router = useRouter()

  if (status === "loading") {
    return <p>Yükleniyor...</p>
  }

  if (status === "unauthenticated") {
    router.push("/")
    return null
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Profil</h1>
      {session?.user && (
        <div className="flex flex-col items-center sm:items-start text-center sm:text-left sm:flex-row sm:space-x-6">
          {session.user.image && (
            <Image
              src={session.user.image}
              alt={session.user.name || "User"}
              width={100}
              height={100}
              className="rounded-full mb-4 sm:mb-0"
            />
          )}
          <div className="space-y-2">
            <h2 className="text-2xl font-semibold">{session.user.name}</h2>
            <p className="text-zinc-600">{session.user.email}</p>
            <button
              onClick={() => signOut({ callbackUrl: '/' })}
              className="mt-4 px-5 py-2 font-semibold text-white bg-red-500 rounded-md hover:bg-red-600 transition-colors"
            >
              Çıkış Yap
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
