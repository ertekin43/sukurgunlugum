import { getServerSession } from "next-auth"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import { supabase } from "@/lib/supabase"
import { redirect } from "next/navigation"

type Note = {
  id: number
  content: string
  created_at: string
}

async function getNotes(userId: string): Promise<Note[]> {
  const { data, error } = await supabase
    .from("notes")
    .select("id, content, created_at")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Notları çekerken hata:", error)
    return []
  }
  return data
}

export default async function Gecmis() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    // Oturum yoksa veya kullanıcı ID'si tanımsız ise giriş sayfasına yönlendir.
    redirect("/")
  }

  const notes = await getNotes(session.user.id)

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Geçmiş Notların</h1>
      {notes.length > 0 ? (
        <ul className="space-y-4">
          {notes.map((note) => (
            <li key={note.id} className="p-4 bg-white border border-zinc-200 rounded-md shadow-sm">
              <p className="text-zinc-800">{note.content}</p>
              <p className="text-sm text-zinc-500 mt-2">
                {new Date(note.created_at).toLocaleDateString("tr-TR", {
                  year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
                })}
              </p>
            </li>
          ))}
        </ul>
      ) : (
        <p>Henüz hiç not kaydetmemişsin.</p>
      )}
    </div>
  )
}
