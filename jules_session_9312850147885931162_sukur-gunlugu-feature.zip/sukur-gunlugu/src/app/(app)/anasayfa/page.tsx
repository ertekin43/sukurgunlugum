import { addNote } from "./actions"

export default function Anasayfa() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Bugün Neler İçin Minnettarsın?</h1>
      <form action={addNote}>
        <textarea
          name="content"
          placeholder="Bugün şükrettiğin 3 şeyi yaz..."
          className="w-full h-40 p-4 border border-zinc-200 rounded-md focus:ring-2 focus:ring-blue-500 focus:outline-none transition-shadow"
          required
        />
        <button
          type="submit"
          className="mt-4 px-6 py-2 font-semibold text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:bg-blue-300 transition-colors"
        >
          Kaydet
        </button>
      </form>
    </div>
  )
}
