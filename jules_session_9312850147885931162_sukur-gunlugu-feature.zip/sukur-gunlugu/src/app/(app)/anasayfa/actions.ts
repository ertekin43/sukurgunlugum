"use server"

import { getServerSession } from "next-auth"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import { supabase } from "@/lib/supabase"
import { revalidatePath } from "next/cache"

export async function addNote(formData: FormData) {
  const content = formData.get("content")?.toString()
  if (!content) {
    return { error: "İçerik boş olamaz." }
  }

  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return { error: "Yetkisiz işlem." }
  }

  const userId = session.user.id

  const { error } = await supabase
    .from("notes")
    .insert([{ content, user_id: userId }])

  if (error) {
    console.error("Not eklerken hata:", error)
    return { error: "Not kaydedilirken bir hata oluştu." }
  }

  // Not eklendikten sonra 'Geçmiş' sayfasının verilerini yeniden doğrula (önbelleği temizle)
  // Bu, yeni eklenen notun listede hemen görünmesini sağlar.
  revalidatePath("/gecmis")

  return { success: "Şükür notun başarıyla kaydedildi!" }
}
