"use client";

import { useSession, signIn, signOut } from "next-auth/react";
import Image from "next/image";

export default function Home() {
  const { data: session } = useSession();

  if (session) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-zinc-50 font-sans">
        <div className="text-center">
          <h1 className="text-2xl font-semibold mb-2">Hoş Geldin, {session.user?.name}</h1>
          {session.user?.image && (
            <Image
              src={session.user.image}
              alt="User avatar"
              width={80}
              height={80}
              className="rounded-full mx-auto mb-4"
            />
          )}
          <p className="mb-4">Giriş yapıldı: {session.user?.email}</p>
          <button
            onClick={() => signOut()}
            className="px-4 py-2 font-semibold text-white bg-red-500 rounded-md hover:bg-red-600 transition-colors"
          >
            Çıkış Yap
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-zinc-50 font-sans">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-6">Şükür Günlüğü</h1>
        <p className="mb-8">Devam etmek için lütfen giriş yapın.</p>
        <button
          onClick={() => signIn("google")}
          className="flex items-center justify-center gap-2 px-6 py-3 font-semibold text-zinc-600 bg-white border border-solid border-zinc-200 rounded-md hover:bg-zinc-100 transition-colors"
        >
          Google ile Giriş Yap
        </button>
      </div>
    </div>
  );
}
